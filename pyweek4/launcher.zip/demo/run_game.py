from directicus.engine import Engine

if __name__=='__main__':
    e = Engine()
    e.run()
