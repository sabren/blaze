if __name__=='__main__':
    from directicus.engine import Engine
    e = Engine()
    e.run()
