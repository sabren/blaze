
from distutils.core import setup

setup(name='Directicus',
      version='0.1',
      author='Team Trailblazer',
      url='http://blazeofglory.org/projects/directicus',
      packages=['directicus'])

setup(name='eventnet',
      packages=['eventnet'])
